// Initialize Speech Recognition
const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
recognition.lang = "en-US";
recognition.continuous = true;

let isAwake = false;

// Text-to-Speech Function with Male Voice
function speak(text) {
    const speech = new SpeechSynthesisUtterance(text);
    const voices = window.speechSynthesis.getVoices();
    speech.voice = voices.find(voice => voice.name.includes("David") || voice.name.includes("Alex") || voice.gender === "male") || voices[0];
    speech.pitch = 1;
    speech.rate = 1;
    speech.volume = 1; // Ensure the volume is set to maximum for loud responses
    window.speechSynthesis.speak(speech);
}

// Show or Hide Listening Indicator
function setListening(state) {
    const indicator = document.getElementById("listening-indicator");
    indicator.style.visibility = state ? "visible" : "hidden";
}

// Append Messages to Chatbox
function appendMessage(message, className) {
    const chatBox = document.getElementById("output-box");
    const messageElement = document.createElement("p");
    messageElement.className = className;
    messageElement.textContent = message;
    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight;
}

// Handle Commands
function handleCommand(command) {
    let response = "";

    // Application URLs
    const appCommands = {
        "open google": "https://www.google.com",
        "open youtube": "https://www.youtube.com",
        "open facebook": "https://www.facebook.com",
        "open instagram": "https://www.instagram.com",
        "open whatsapp": "https://web.whatsapp.com",
        "open twitter": "https://twitter.com",
        "open linkedin": "https://www.linkedin.com",
        "open gmail": "https://mail.google.com",
        "open maps": "https://www.google.com/maps",
        "open drive": "https://drive.google.com",
        "open photos": "https://photos.google.com",
        "open calendar": "https://calendar.google.com",
        "open play store": "https://play.google.com/store",
        "open spotify": "https://www.spotify.com",
        "open netflix": "https://www.netflix.com",
        "open amazon": "https://www.amazon.com",
        "open ebay": "https://www.ebay.com",
        "open wikipedia": "https://www.wikipedia.org",
        "open reddit": "https://www.reddit.com",
        "open github": "https://www.github.com"
    };

    // Check Command
    if (command in appCommands) {
        response = `Opening ${command.split(" ")[1]}.`;
        window.open(appCommands[command], "_blank");
    } else if (/what time/i.test(command)) {
        response = `The time is ${new Date().toLocaleTimeString()}.`;
    } else if (/what is your name/i.test(command)) {
        response = "I am Bob, your virtual assistant!";
    } else if (/how are you/i.test(command)) {
        response = "I am functioning perfectly, thank you!";
    } else if (/stop listening/i.test(command)) {
        response = "Okay, I will stop listening now. Say 'Hey Bob' to wake me up.";
        isAwake = false;
        setListening(false);
    } else {
        response = "Sorry, I didn't catch that. Can you try again?";
    }

    if (response) {
        speak(response); // Ensure all responses are spoken
        appendMessage(response, "assistant-message");
    }
}

// Recognition Result
recognition.onresult = (event) => {
    const transcript = event.results[event.results.length - 1][0].transcript.trim().toLowerCase();

    if (!isAwake && transcript.includes("hey bob")) {
        isAwake = true;
        speak("Hello buddy, how can I help you?");
        appendMessage("Hello buddy, how can I help you?", "assistant-message");
        setListening(true);
    } else if (isAwake) {
        handleCommand(transcript);
    }
};

// Start Recognition
recognition.start();
